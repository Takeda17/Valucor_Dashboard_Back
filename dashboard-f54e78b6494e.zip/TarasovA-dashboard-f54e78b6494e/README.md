# Dashboard

## Requirements

- php - 8
- node js - 14.18.1
- mysql

## Installation

1. [Install php](#install-php)
2. [Install composer](#install-composer)
3. [Install nodejs](#install-nvm-and-nodejs)
4. Configure app
    * Create database
    * Copy .env file `cp .env.example .env`and add database(name, user, password)
    * run `composer install`
    * run `npm install`
    * Generate key `php artisan key:generate`
    * Run migrate `php artisan migrate`
    * Create user `php artisan create:user`
    * (Static: css, js) For development `npm run dev` or `npm run prod` for production mode
    * `php artisan storage:link`


### Install php

- `sudo apt install software-properties-common`
- `sudo add-apt-repository ppa:ondrej/php`
- `sudo apt install php8.0-{fpm,cli,common,curl,intl,mysql,readline,xml,mbstring,xdebug,zip,dom,pdo}`

### Install composer
- `curl -sS https://getcomposer.org/installer -o composer-setup.php`
- `php composer-setup.php --install-dir=/usr/local/bin --filename=composer`

### Install nvm and nodejs
- `curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.35.3/install.sh | bash`
- `source ~/.bashrc`
- `nvm install 14.18.1`

    #### Or install nodejs via apt
    `sudo apt install nodejs`

